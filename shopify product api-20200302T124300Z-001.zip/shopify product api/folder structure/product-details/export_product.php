<?php

ob_start();
// error_reporting(0); 
include('../config.php');
		$query = "SELECT id,product_title,image_src,product_sku,price,compare_at_price,barcode,inventory_quantity,weight,product_id FROM product_detail";
		if (!$result = mysqli_query($con, $query)) {
			exit(mysqli_error($con));
		}

		$users = array();
		if (mysqli_num_rows($result) > 0) {
			while ($row = mysqli_fetch_assoc($result)) {
				$users[] = $row;
			}
		}
		header('Content-Type: text/csv; charset=utf-8');
		header('Content-Disposition: attachment; filename=products.csv');
		$output = fopen('php://output', 'w');
		fputcsv($output, array('No', 'Title', 'Image', 'Sku','Price','Compare Price','Barcode','Inventory','Weight','ProductId'));

		if (count($users) > 0) {
			foreach ($users as $row) {
				fputcsv($output, $row);
			}
		}
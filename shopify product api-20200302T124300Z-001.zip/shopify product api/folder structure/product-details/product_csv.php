<?php
ob_start();
// error_reporting(0); 
include('../config.php');
//error_reporting(E_ALL & ~E_NOTICE);
require '../vendor/autoload.php';
use GuzzleHttp\Client;
$dotenv = new Dotenv\Dotenv(__DIR__);
$dotenv->load();


$store= 'store-data-app.myshopify.com'; 
$select = $con->query("SELECT access_token FROM installs WHERE store = '$store'");
$user = $select->fetch_object();
 $access_token = $user->access_token;
$client = new Client();

$arr = array();
$file = fopen('pro_csv.csv', 'r');
while (($line = fgetcsv($file)) !== FALSE) {

  $arr[] =$line;
  } 
 
echo '<pre>';
fclose($file);
$final=array();
foreach ($arr as $index=>$row){
	if($index>0){
		foreach($arr[0] as $position=>$header){
			$t[$header]=$row[$position];
		}
		$final[]=$t;
	}
}
print_r($final);
foreach($final as $val){
	
	  $access_token ="bbe56760319d991bb8447e47bdf5ba70";
		 $product_title = $val['Title'];
		 //$description = $val['description'];
		 $description = "description";
		 $product_sku = $val['Sku'];
		 $price = $val['Price'];
		 $compare_at_price = $val['Compare Price'];
		 $barcode = $val['Barcode'];
		 $inventory_quantity = $val['Inventory'];
		 $weight = $val['Weight'];
		 $Image = $val['Image'];
		 $pid = $val['ProductId'];
 		
			 
			 
			 	$response = $client->request(
					   'PUT', 
						"https://{$store}/admin/products/$pid.json",
					   [
						   'query' => [          
							"product"=> [
							"title"=> $product_title,
							"body_html"=> $description,
							"variant"=> [ 
							"sku"=> $product_sku,
							"barcode"=> $barcode,
							"weight"=> $weight,
							"inventory_quantity"=>$inventory_quantity,
							"compare_at_price"=>$compare_at_price,
							"price"=> $price
							]
					],
							   'access_token' => $access_token
						   ]
					   ]
					);
			
			$result2 = json_decode($response->getBody()->getContents(), true); 
			
	
}
if($result2){
				echo "success";
			}
?>
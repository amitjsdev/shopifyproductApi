<?php

ob_start();
// error_reporting(0); 
include('../config.php');
//error_reporting(E_ALL & ~E_NOTICE);
require '../vendor/autoload.php';
use GuzzleHttp\Client;
$dotenv = new Dotenv\Dotenv(__DIR__);
$dotenv->load();


$store= 'store-data-app.myshopify.com'; 
$select = $con->query("SELECT access_token FROM installs WHERE store = '$store'");
$user = $select->fetch_object();
 $access_token = $user->access_token;
$client = new Client();


	?>
	
	<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

.form-inline {  
 /*  display: grid;
  flex-flow: row wrap;
  align-items: center; */
}

.form-inline label {
/*   margin: 5px 10px 5px 0; */
}

.form-inline input {
  vertical-align: middle;
  margin: 5px 10px 5px 0;
  padding: 10px;
  background-color: #fff;
  border: 1px solid #ddd;
}

.form-inline button {
  padding: 10px 20px;
  background-color: dodgerblue;
  border: 1px solid #ddd;
  color: white;
  cursor: pointer;
}

.form-inline button:hover {
  background-color: royalblue;
}

@media (max-width: 800px) {
  .form-inline input {
    margin: 10px 0;
  }
  
  .form-inline {
    flex-direction: column;
    align-items: stretch;
  }
}
.updatehead{
	text-align: center;
}
.prdctedit{
	/* text-align: center; */
    margin: auto;
    width: 50%;
    border: 3px solid green;
    padding: 10px;
}
</style>
</head>
<body>

<h2 class="updatehead">Add New Product</h2>



				<div class="prdctedit">
				<form class="form-inline" method="post" action="">
				  <label for="product_title">product_title:</label></br>
					<input type="text" value="" name="product_title"></br></br>
					<label for="product_title">Description:</label></br>
					<input type="text" value="" name="description"></br></br>
				  <label for="email">product_sku:</label></br>
					<input type="text" value="" name="product_sku"></br></br>
					  <label for="email">price:</label></br>
					<input type="text" value="" name="price"></br></br>
					  <label for="email">compare_at_price:</label></br>
					<input type="text" value="" name="compare_at_price"></br></br>
					  <label for="email">barcode:</label></br>
					<input type="text" value="" name="barcode"></br></br>
					  <label for="email">inventory_quantity:</label></br>
					<input type="text" value="" name="inventory_quantity"></br></br>
					  <label for="email">weight:</label></br>
					<input type="text" value="" name="weight"></br></br>


				  <input value="Submit" name="submit" type="submit">
				</form>
				</div>
<?php
	}
	if(isset($_POST['submit'])){
		 // $access_token ="bbe56760319d991bb8447e47bdf5ba70";
		 $product_title = $_POST['product_title'];
		 $description = $_POST['description'];
		 $product_sku = $_POST['product_sku'];
		 $price = $_POST['price'];
		 $compare_at_price = $_POST['compare_at_price'];
		 $barcode = $_POST['barcode'];
		 $inventory_quantity = $_POST['inventory_quantity'];
		 $weight = $_POST['weight'];
		
					$response = $client->request(
					   'POST', 
						"https://{$store}/admin/products.json",
					   [
						   'query' => [          
							"product"=> [
							"title"=> $product_title,
							"body_html"=> $description,
							"variant"=> [
							"sku"=> $product_sku,
							"barcode"=> $barcode,
							"weight"=> $weight,
							"inventory_quantity"=>$inventory_quantity,
							"compare_at_price"=>$compare_at_price,
							"price"=> $price
							]
					],
							   'access_token' => $access_token
						   ]
					   ]
					);
			
			$result2 = json_decode($response->getBody()->getContents(), true);
			echo "<pre>";
			print_r($result2);
			echo "</pre>";
	/* 	if($result2){
				$update_sql="UPDATE `product_detail` set product_title='$product_title',description='$description',image_src='$records_image', product_sku='$product_sku', price='$price', compare_at_price='$compare_at_price', barcode='$barcode', inventory_quantity='$inventory_quantity', weight='$weight' where  product_id='$get_product_id'";
				$reslt=mysqli_query($con,$update_sql);	
				if($reslt){
						echo "<script>alert('Form Submitted successfully!');</script>";
						 echo "<script>window.location ='http://139.59.172.102/store-data-records/product-details/products_edit.php?product_id=".$pid."'</script>";
					}
			} */
	}
	?>
</body>
</html>

<?php

ob_start();
 error_reporting(0); 
include('../config.php');
//error_reporting(E_ALL & ~E_NOTICE);
require '../vendor/autoload.php';
use GuzzleHttp\Client;
$dotenv = new Dotenv\Dotenv(__DIR__);
$dotenv->load();


$store= 'store-data-app.myshopify.com'; 
$select = $con->query("SELECT access_token FROM installs WHERE store = '$store'");
$user = $select->fetch_object();
$access_token = $user->access_token;
 $access_token ="bbe56760319d991bb8447e47bdf5ba70";
$client = new Client();


					/* orders */
	$response_orders = $client->request(
		'GET', 
		"https://{$store}/admin/orders.json",
		[
			'query' => [
				'fields' => 'id,created_at,line_items,customer,name',
				'access_token' => $access_token,
				'limit' =>200
			]
		]	
		);
		$count=1;
		$result_orders = json_decode($response_orders->getBody()->getContents(), true);

 	 /*   echo "<pre>";
		print_r($result_orders);  */  
		//die;  

			if($result_orders !=""){
				foreach ($result_orders['orders'] as $key=>$value){
					$product_id=$value['line_items'][0]['product_id'];
					$customer_id=$value['customer']['id'];
					$email=$value['customer']['email'];
					 $shop_id=$value['name'];
					 $created_at=$value['created_at'];
					 $created_at = substr($created_at, 0, strpos($created_at, "T"));
					//echo str_replace("world","Peter","Hello world!");
					foreach($value['line_items'] as $key=>$secondVal){
						$order_id=$secondVal['id'];
					
						
						$sql ="SELECT * FROM new_invoice where shop_id='".$shop_id."'";
						$result_num = $con->query($sql);
						$num_rows=$result_num->num_rows; 
						if($num_rows == ""){
							$insert_product="INSERT INTO new_invoice(customer_id,created_at,shop_id,email) VALUES ('$customer_id','$created_at','$shop_id','$email')";	
						
							if($con->query($insert_product) === TRUE){
								echo "Insert sucess fully";
							}
									
						}else{
							$update_sql="UPDATE `new_invoice` set customer_id='$customer_id', created_at='$created_at',email='$email' where shop_id='$shop_id'";
							$reslt=mysqli_query($con,$update_sql);	
							if($reslt){
							
							}

						}
					}			
				}
			}
			/* orders end */
if($access_token){
	?>
	
	<!DOCTYPE html>
	<html>
	<head>
		<link rel="stylesheet" href="../app-style.css">
		<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/demo.css">
	</head>
	<body>
<style>
.table_main{
    width: 100%;
    text-align: center;
}
.listHeading{
	text-align: center;
}
.table_main th{
	text-align: center;
}
</style>
	<div id="plisting" class="tabcontent active">
	<h1 class="listHeading"> List Of New Invoice</h1>
		<table class="table_main" border="1">
			<thead>
				<tr class="trtop_gapiheading main_porduct_table">
					<th class="firstTh">Sr No.</th>
					<!--<th class="secondTh">product_id</th>-->
					<th class="secondTh">Order ID</th>
					<th class="thirdTh">customer_id</th>
					<th class="thirdTh">created_at</th>
					<th class="thirdTh">status</th>
					<th class="thirdTh">Send Invoice</th>
				
				</tr>
			</thead>
			 <tbody> 
				<?php
				$sql ="SELECT * FROM new_invoice";
				$result_num = $con->query($sql);
				$num_rows=$result_num->num_rows; 
				$row=mysqli_fetch_assoc($result_num);
				if($num_rows !=""){
					$i=1;
						/* 		$update_sql="UPDATE `orders_detail` set product_title='$product_title', quantity='$quantity', price='$price', created_at='$created_at', vendor='$vendor', tax_lines='$tax_lines', country_code='$country_code', province_code='$province_code', name='$name', address='$address', city='$city', zip='$zip' where  product_id='$product_id AND order_id='$order_id'"; */
						/* 	echo "<pre>";
						print_r($row); */
					foreach($result_num as $val_result){
					
						?>
							<tr class='trtop_gapi '> 
								<td><?php echo $i;?></td>
								<td class='tdtop_gapi'><?php echo $val_result['shop_id'];  ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['customer_id'];  ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['created_at']; ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['status']; ?></td>
								<td><a href="send_invoice.php?shop_id=<?php echo $val_result['shop_id'];?>&shop=<?php echo $store;?>&email=<?php echo $email;?>">Send</a></td>
							</tr>	
						<?php
						$i++;
					}
				 }
				?>
			</tbody>
		</table>
	</div>
<?php 

}else{
	$store = $store;
	$factory = new RandomLib\Factory;
	$generator = $factory->getMediumStrengthGenerator();
	$nonce = $generator->generateString(20);

	$api_key = getenv('SHOPIFY_APIKEY');
	$scopes = getenv('SHOPIFY_SCOPES');
	$redirect_uri = urlencode(getenv('SHOPIFY_REDIRECT_URI'));
    $select = $db->query("SELECT nonce FROM installs WHERE store = '$store'");
	if($select->num_rows > 0){
		$updatenonce = "UPDATE installs SET nonce ='$nonce' WHERE store='$store'";
		$query_updatenonce = $db->query($updatenonce);
		
		$url = "https://{$store}/admin/oauth/authorize?client_id={$api_key}&scope={$scopes}&redirect_uri={$redirect_uri}&state={$nonce}";
		header("Location: {$url}");
	}else{
		if ($query = $db->prepare('INSERT INTO installs SET store = ?, nonce = ?, access_token = ""')) {
			$query->bind_param('ss', $store, $nonce);
			$query->execute();
			$query->close();
			$url = "https://{$store}/admin/oauth/authorize?client_id={$api_key}&scope={$scopes}&redirect_uri={$redirect_uri}&state={$nonce}";
			header("Location: {$url}");
		}
	}
}
?>
</body>
</html>
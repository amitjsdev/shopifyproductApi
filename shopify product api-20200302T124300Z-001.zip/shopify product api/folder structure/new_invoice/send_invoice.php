<?php

ob_start();
// error_reporting(0); 
include('../config.php');
//error_reporting(E_ALL & ~E_NOTICE);
require '../vendor/autoload.php';
use GuzzleHttp\Client;
$dotenv = new Dotenv\Dotenv(__DIR__);
$dotenv->load();


$store= 'store-data-app.myshopify.com'; 
$select = $con->query("SELECT access_token FROM installs WHERE store = '$store'");
$user = $select->fetch_object();
 $access_token = $user->access_token;
$client = new Client();

$shop_id=$_GET['shop_id'];
$update_sql="UPDATE `new_invoice` set status='1' where shop_id='$shop_id'";
							$reslt=mysqli_query($con,$update_sql);	
							if($reslt){
										$to = $_GET['email'];
										$subject = "New Invoice ";
										$txt = "Thanks";
										$headers = "From: amit4510201@gmail.com" . "\r\n";
										$headers .= "MIME-Version: 1.0\r\n";
										$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

										mail($to,$subject,$txt,$headers);
							echo "<script>alert('Invocie Sended successfully!');</script>";
							echo "<script>window.location ='http://139.59.172.102/store-data-records/new_invoice/new_invoice.php'</script>";
					}
							



	?>

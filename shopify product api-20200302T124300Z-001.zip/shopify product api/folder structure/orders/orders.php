<?php

ob_start();
 error_reporting(0); 
include('../config.php');
//error_reporting(E_ALL & ~E_NOTICE);
require '../vendor/autoload.php';
use GuzzleHttp\Client;
$dotenv = new Dotenv\Dotenv(__DIR__);
$dotenv->load();


$store= 'store-data-app.myshopify.com'; 
$select = $con->query("SELECT access_token FROM installs WHERE store = '$store'");
$user = $select->fetch_object();
$access_token = $user->access_token;
 $access_token ="bbe56760319d991bb8447e47bdf5ba70";
$client = new Client();


					/* orders */
	$response_orders = $client->request(
		'GET', 
		"https://{$store}/admin/orders.json",
		[
			'query' => [
				'fields' => 'id,created_at,line_items,customer',
				'access_token' => $access_token,
				'limit' =>200
			]
		]	
		);
		$count=1;
		$result_orders = json_decode($response_orders->getBody()->getContents(), true);

 	   echo "<pre>";
		print_r($result_orders);   
		//die;  
		
	/* 	$sql_date ="SELECT * FROM app_date where store_id='".$store_id."'";
		$result_date = mysqli_query($db, $sql_date);
		$row_date=mysqli_fetch_assoc($result_date);
		$r_date=$row_date['created_date']; */
			if($result_orders !=""){
				foreach ($result_orders['orders'] as $key=>$value){
					$product_id=$value['line_items'][0]['product_id'];
					 $created_at=$value['created_at'];
					 $created_at = substr($created_at, 0, strpos($created_at, "T"));
					//echo str_replace("world","Peter","Hello world!");
					foreach($value['line_items'] as $key=>$secondVal){
						$order_id=$secondVal['id'];
						$variant_id=$secondVal['variant_id'];
						$product_title=$secondVal['title'];
						$quantity=$secondVal['quantity'];
						$price=$secondVal['price'];
						/*  echo "<pre>";
						print_r($secondVal); */
						$vendor=$secondVal['vendor'];
						$tax_lines=$secondVal['tax_lines'][0]['price_set']['shop_money']['amount'];
						$currency_code=$secondVal['tax_lines'][0]['price_set']['shop_money']['currency_code'];
						$country_code=$secondVal['origin_location']['country_code'];
						$province_code=$secondVal['origin_location']['province_code'];
						$name=$secondVal['origin_location']['name'];
						$address1=$secondVal['origin_location']['address1'];
						$address2=$secondVal['origin_location']['address2'];
						$address=$address1 .','. $address2;
						$city=$secondVal['origin_location']['city'];
						$zip=$secondVal['origin_location']['zip'];
						
						$sql ="SELECT * FROM orders_detail where order_id='".$order_id."'";
						$result_num = $con->query($sql);
						$num_rows=$result_num->num_rows; 
						if($num_rows == ""){
							$insert_product="INSERT INTO orders_detail(product_id,order_id,variant_id,product_title,quantity,price,created_at,vendor,tax_lines,country_code,province_code,name,address,city,zip) VALUES ('$product_id','$order_id','$variant_id','$product_title','$quantity','$price','$created_at','$vendor','$tax_lines','$country_code','$province_code','$name','$address','$city','$zip')";	
						
							if($con->query($insert_product) === TRUE){
								echo "Insert sucess fully";
							}
									
						}else{
							$update_sql="UPDATE `orders_detail` set product_title='$product_title', quantity='$quantity', price='$price', created_at='$created_at', vendor='$vendor', tax_lines='$tax_lines', country_code='$country_code', province_code='$province_code', name='$name', address='$address', city='$city', zip='$zip' where  product_id='$product_id' AND order_id='$order_id'";
							$reslt=mysqli_query($con,$update_sql);	
							if($reslt){
							//echo "Update success";
							}

						}
					}			
				}
			}
			/* orders end */
if($access_token){
	?>
	
	<!DOCTYPE html>
	<html>
	<head>
		<link rel="stylesheet" href="../app-style.css">
		<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/demo.css">
	</head>
	<body>
<style>
.table_main{
    width: 100%;
    text-align: center;
}
.listHeading{
	text-align: center;
}
</style>
	<div id="plisting" class="tabcontent active">
	<h1 class="listHeading"> List Of All Orders</h1>
		<table class="table_main" border="1">
			<thead>
				<tr class="trtop_gapiheading main_porduct_table">
					<th class="firstTh">Sr No.</th>
					<!--<th class="secondTh">product_id</th>-->
					<th class="secondTh">Title</th>
					<th class="thirdTh">Quantity</th>
					<th class="thirdTh">Price</th>
					<th class="thirdTh">Created</th>
					<th class="thirdTh">Vendor</th>
					<th class="thirdTh">Tax</th>
					<th class="thirdTh">Country Code</th>
					<th class="thirdTh">Province Code</th>
					<th class="thirdTh">Name</th>
					<th class="thirdTh">Address</th>
					<th class="thirdTh">City</th>
					<th class="thirdTh">Zip</th>
					<th class="fourthTh">Action</th>
				</tr>
			</thead>
			 <tbody> 
				<?php
				$sql ="SELECT * FROM orders_detail";
				$result_num = $con->query($sql);
				$num_rows=$result_num->num_rows; 
				$row=mysqli_fetch_assoc($result_num);
				if($num_rows !=""){
					$i=1;
						/* 		$update_sql="UPDATE `orders_detail` set product_title='$product_title', quantity='$quantity', price='$price', created_at='$created_at', vendor='$vendor', tax_lines='$tax_lines', country_code='$country_code', province_code='$province_code', name='$name', address='$address', city='$city', zip='$zip' where  product_id='$product_id AND order_id='$order_id'"; */
						/* 	echo "<pre>";
						print_r($row); */
					foreach($result_num as $val_result){
					
						?>
							<tr class='trtop_gapi '> 
								<td><?php echo $i;?></td>
								<td class='tdtop_gapi title'>
								<a href="//<?php echo $store; ?>/admin/products/<?php echo $val_result['product_id']; ?>" target="_blank"><?php echo $val_result['product_title'];  ?></a></td>
								<!--<td class='tdtop_gapi'><?php echo $val_result['product_title'];  ?></td>-->
								<td class='tdtop_gapi'><?php echo $val_result['quantity']; ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['price'];  ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['created_at'];  ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['vendor'];  ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['tax_lines'];  ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['country_code'];  ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['province_code'];  ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['name'];  ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['address'];  ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['city'];  ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['zip'];  ?></td>
								<!--<td><a href="ques_edit.php?question_id=<?php echo $row['id'];?>&shop=<?php echo $store;?>">Edit</a>
								</td>-->
							</tr>	
						<?php
						$i++;
					}
				 }
				?>
			</tbody>
		</table>
	</div>
<?php 

}else{
	$store = $store;
	$factory = new RandomLib\Factory;
	$generator = $factory->getMediumStrengthGenerator();
	$nonce = $generator->generateString(20);

	$api_key = getenv('SHOPIFY_APIKEY');
	$scopes = getenv('SHOPIFY_SCOPES');
	$redirect_uri = urlencode(getenv('SHOPIFY_REDIRECT_URI'));
    $select = $db->query("SELECT nonce FROM installs WHERE store = '$store'");
	if($select->num_rows > 0){
		$updatenonce = "UPDATE installs SET nonce ='$nonce' WHERE store='$store'";
		$query_updatenonce = $db->query($updatenonce);
		
		$url = "https://{$store}/admin/oauth/authorize?client_id={$api_key}&scope={$scopes}&redirect_uri={$redirect_uri}&state={$nonce}";
		header("Location: {$url}");
	}else{
		if ($query = $db->prepare('INSERT INTO installs SET store = ?, nonce = ?, access_token = ""')) {
			$query->bind_param('ss', $store, $nonce);
			$query->execute();
			$query->close();
			$url = "https://{$store}/admin/oauth/authorize?client_id={$api_key}&scope={$scopes}&redirect_uri={$redirect_uri}&state={$nonce}";
			header("Location: {$url}");
		}
	}
}
?>
</body>
</html>
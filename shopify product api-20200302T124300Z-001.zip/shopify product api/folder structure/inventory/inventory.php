<?php

ob_start();
// error_reporting(0); 
include('../config.php');
//error_reporting(E_ALL & ~E_NOTICE);
require '../vendor/autoload.php';
use GuzzleHttp\Client;
$dotenv = new Dotenv\Dotenv(__DIR__);
$dotenv->load();


$store= 'store-data-app.myshopify.com'; 
$select = $con->query("SELECT access_token FROM installs WHERE store = '$store'");
$user = $select->fetch_object();
$access_token = $user->access_token;
 $access_token ="bbe56760319d991bb8447e47bdf5ba70";
$client = new Client();


if($access_token){
	?>
	
	<!DOCTYPE html>
	<html>
	<head>
		<link rel="stylesheet" href="../app-style.css">
		<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/demo.css">
	</head>
	<body>
<style>
.table_main{
    width: 100%;
    text-align: center;
}
.table_main th{
    text-align: center;
}
.listHeading{
	text-align: center;
}
</style>
	<div id="plisting" class="tabcontent active">
		<h1 class="listHeading">List Of All Products</h1>
		<div class="exportProduct">
		<form method="post" action="export_inventory.php">
		<button type="submit" name="exportProducy">Export Product</button>
		</form>
		</div>
	<table class="table_main" border="1">
							<thead>
								<tr class="trtop_gapiheading main_porduct_table">
								<th class="firstTh">Sr No.</th>
								<th class="secondTh">Title</th>
								<th class="thirdTh">Image</th>
								<th class="thirdTh">Quantity</th>
								</tr>
							</thead>
							 <tbody> 
			<?php

			$response2 = $client->request(
			'GET', 
			"https://{$store}/admin/products/count.json",
			[
				'query' => [
					'fields' => 'id,vendor,images,title,variants',
					'access_token' => $access_token
				]
			]	
			);
			$result2 = json_decode($response2->getBody()->getContents(), true);
		 $countProducts= $result2['count'];
			if(isset($_GET["page"])){
			$page = (int)$_GET["page"];
			}
			else{
				$page = 1;
			}
			$setLimit = 50;

			$pageLimit = ($page * $setLimit) - $setLimit;
			$response = $client->request(
			'GET', 
			"https://{$store}/admin/products.json",
			[
				'query' => [
					'fields' => 'id,vendor,images,title,variants',
					'access_token' => $access_token,
					'limit' => $setLimit,
					'page'=> $page
				]
			]	
		);
		$count=1;
		$result = json_decode($response->getBody()->getContents(), true);
		
	 /*  	echo "<pre>";
		print_r($result);    */
		//$count=1;
		$i=1;
		foreach ($result['products'] as $products_details){ 
			$count++;

			$records_ProductTitle= $products_details['title'];
			$records_sku = $products_details['variants'][0]['sku'];
			$product_shopify_VarientsId = $products_details['variants'][0]['id'];
			$product_shopify_VarientsIds = $products_details['variants'];
			$records_ProductId = $products_details['id'];
			$records_ProductPrice = $products_details['variants'][0]['price'];
			$records_ProductBarcode = $products_details['variants'][0]['barcode'];				
			$product_shopify_title = $products_details['title'];
			$records_image = $products_details['images'][0]['src'];
			
				foreach($product_shopify_VarientsIds as $all_var_records){
					$records_ProductId = $all_var_records['id'];
					$records_Product_Id = $all_var_records['product_id'];
					$records_ProductPrice = $all_var_records['price'];
					$records_sku = $all_var_records['sku'];
					$records_ProductBarcode = $all_var_records['barcode'];
					$inventory_quantity = $all_var_records['inventory_quantity'];
					$weight = $all_var_records['weight'];
					$compare_at_price = $all_var_records['compare_at_price'];
					
					$resltTruncate = $con->query("TRUNCATE TABLE product_inventory");
					$results = $con->query("SELECT * FROM product_inventory where product_id = '$records_Product_Id'");		
					 if($results->num_rows == ""){
						 	
 $ans="insert into product_inventory(product_id,product_title,inventory_quantity)values('$records_Product_Id','$records_ProductTitle','".$inventory_quantity."')";	
	
						$reslt=mysqli_query($con,$ans);	
						if($reslt){
						//	echo "success";
						}
					 }else{
						$update_sql="UPDATE `product_inventory` set product_title='$records_ProductTitle',inventory_quantity='$inventory_quantity' where  product_id='$records_Product_Id'";
					
						$reslt=mysqli_query($con,$update_sql);	
						if($reslt){
							//echo "Update success";
						}
					 }
					?>
					<tr class='trtop_gapi '> 
						<td><?php echo $i;?></td>
						<td class='tdtop_gapi title'><a href="//<?php echo $store; ?>/admin/products/<?php echo $records_Product_Id; ?>" target="_blank"><?php echo $records_ProductTitle;  ?></a></td>
						<td class='tdtop_gapi'><img class="pimageapp" src="<?php echo $records_image;  ?>"></td>
						<td class='tdtop_gapi'><?php echo $inventory_quantity;  ?></td>
						<!--<td><a href="ques_edit.php?question_id=<?php echo $row['id'];?>&shop=<?php echo $store;?>">Edit</a></td>-->
					</tr>	
				<?php
				$i++;
			}
		 }
			?>
		</tbody>
						</table>
	</div>
<?php 

}else{
	$store = $store;
	$factory = new RandomLib\Factory;
	$generator = $factory->getMediumStrengthGenerator();
	$nonce = $generator->generateString(20);

	$api_key = getenv('SHOPIFY_APIKEY');
	$scopes = getenv('SHOPIFY_SCOPES');
	$redirect_uri = urlencode(getenv('SHOPIFY_REDIRECT_URI'));
    $select = $db->query("SELECT nonce FROM installs WHERE store = '$store'");
	if($select->num_rows > 0){
		$updatenonce = "UPDATE installs SET nonce ='$nonce' WHERE store='$store'";
		$query_updatenonce = $db->query($updatenonce);
		
		$url = "https://{$store}/admin/oauth/authorize?client_id={$api_key}&scope={$scopes}&redirect_uri={$redirect_uri}&state={$nonce}";
		header("Location: {$url}");
	}else{
		if ($query = $db->prepare('INSERT INTO installs SET store = ?, nonce = ?, access_token = ""')) {
			$query->bind_param('ss', $store, $nonce);
			$query->execute();
			$query->close();
			$url = "https://{$store}/admin/oauth/authorize?client_id={$api_key}&scope={$scopes}&redirect_uri={$redirect_uri}&state={$nonce}";
			header("Location: {$url}");
		}
	}
}
?>
</body>
</html>